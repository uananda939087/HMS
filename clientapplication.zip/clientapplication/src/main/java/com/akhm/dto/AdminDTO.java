package com.akhm.dto;

import lombok.Data;

@Data
public class AdminDTO {
	private int adminId;
	private String firstName;
	private String lastName;
	private String emailId;
	private String password;
}
