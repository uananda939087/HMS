package com.akhm.exceptin;

public class MyClientCustomException extends RuntimeException{
	public MyClientCustomException(String message)
	{
		super(message);
	}
}
