package com.akhm.service;

import com.akhm.dto.CustomerDTO;

public interface CustomerService {
	public Integer insertCustomer(CustomerDTO customerDTO);
	public CustomerDTO getCustomer(CustomerDTO customerDTO);
	public boolean isCustomerExist(String emailId);
}
