package com.akhm.service.impl;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.akhm.dto.AdminDTO;
import com.akhm.exceptin.MyClientCustomException;
import com.akhm.service.AdminService;
@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	private RestTemplate restTemplate;

	public AdminDTO getAdmin(String emailId, String password) {
		
		try {
				Map<String, String> admin=new LinkedHashMap<>();
				admin.put("emailId", emailId);
				admin.put("password", password);
				return restTemplate.postForObject("http://localhost:8080/admin/v0/login",admin ,AdminDTO.class );
		} catch (Exception e) {
			throw new MyClientCustomException(e.getMessage());

		}
		
	}
}
