package com.akhm.service.impl;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.akhm.clients.CustomerClient;
import com.akhm.dto.CustomerDTO;
import com.akhm.exceptin.MyClientCustomException;
import com.akhm.service.CustomerService;
@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private CustomerClient customerClient;
	@Override
	public Integer insertCustomer(CustomerDTO customerDTO) {
		try {
			return customerClient.saveUser(customerDTO);
		} catch (Exception e) {
			throw new MyClientCustomException(e.getMessage());
		}
		
	}

	@Override
	public CustomerDTO getCustomer(CustomerDTO customerDTO) {
		
		try {
			 //return restTemplate.postForObject("http://localhost:8088/customer/v1", customerDTO, CustomerDTO.class);
			
			return customerClient.getUser(customerDTO);
		} catch (Exception e) {
			throw new MyClientCustomException(e.getMessage());
		}
	}

	@Override
	public boolean isCustomerExist(String emailId) {
		
		try {
				return  customerClient.isUserExist(emailId);
		} catch (Exception e) {
			throw new MyClientCustomException(e.getMessage());
		}
	}

}
