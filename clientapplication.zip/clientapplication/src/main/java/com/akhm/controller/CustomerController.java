package com.akhm.controller;

import java.lang.ProcessBuilder.Redirect;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.akhm.controller.command.CustomerCommand;
import com.akhm.dto.CustomerDTO;
import com.akhm.dto.UserDTO;
import com.akhm.service.CustomerService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
@Controller
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@RequestMapping(name="/customerLogin",method = RequestMethod.GET)
	public String showAdminLogin()
	{
		return "customerLogin";
	}
	public String submitCustomerLogin(HttpServletRequest request,@RequestBody CustomerDTO customerDTO)
	{
		customerDTO=customerService.getCustomer(customerDTO);
		if(customerDTO!=null)
		{
			HttpSession session=request.getSession();
			session.setAttribute("AUTH_CUSTOMER", customerDTO);
			return "redirect:customerHome";
		}
		else {
			request.setAttribute("ErrorMessage", "Invalid EmailId or Password");
		}
		return "customerLogin";

	}
	public String submitCustomerRegistration(HttpServletRequest request,@RequestBody CustomerDTO customerDTO)
	{
		Integer customerId=customerService.insertCustomer(customerDTO);
		if(customerDTO!=null)
		{
			HttpSession session=request.getSession();
			session.setAttribute("AUTH_USER", customerDTO);
			return "redirect:customerHome";
		}
		return "customerRegistration";
	}
	@RequestMapping(name="/customerRegistration",method = RequestMethod.GET)
	public String userRegistration()
	{
		return"customerRegistration";
	}
}
