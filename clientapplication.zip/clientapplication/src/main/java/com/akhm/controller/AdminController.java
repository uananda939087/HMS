package com.akhm.controller;

import java.lang.ProcessBuilder.Redirect;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.akhm.controller.command.AdminCommand;
import com.akhm.dto.AdminDTO;
import com.akhm.service.AdminService;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {
	@Autowired
	private AdminService adminService;
	@RequestMapping(name="/adminlogin",method = RequestMethod.GET)
	public String showAdminLogin()
	{
		return "adminLogin";
	}
	public String submitAdminLogin(HttpServletRequest request,AdminCommand adminCommand)
	{
		//Map<String, String> admin=new LinkedHashMap<>();
		//admin.put("emailId", adminCommand.getEmailId());
		//admin.put("password", adminCommand.getPassword());
		AdminDTO adminDTO=adminService.getAdmin(adminCommand.getEmailId(), adminCommand.getPassword());
		if(adminDTO!=null)
		{
			HttpSession session=request.getSession();
			session.setAttribute("AUTH_ADMIN", adminDTO);
			return "redirect:adminHome";
			
		}
		else
		{
			request.setAttribute("errormessage", "invalid emailId or password");
		}
		return "adminLogin";
	}
}
