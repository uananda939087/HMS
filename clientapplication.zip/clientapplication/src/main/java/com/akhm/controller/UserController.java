
package com.akhm.controller;

import java.lang.ProcessBuilder.Redirect;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.akhm.controller.command.UserCommand;
import com.akhm.dto.UserDTO;
import com.akhm.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@RequestMapping(name="/userLogin",method = RequestMethod.GET)
	public String userLogin()
	{
		return"userLogin";
	}
	public String showUserLogin(HttpServletRequest request, @RequestBody UserDTO userDTO)
	{
		userDTO=userService.getUser(userDTO);
		if(userDTO!=null)
		{

			HttpSession session=request.getSession();
			session.setAttribute("AUTH_USER", userDTO);
			return "redirect:userHome";
		}
		else {
			request.setAttribute("errorMessage", "Invalid EmailId Or Password");
		}
		
		return "userLogin";
	}
	public String submitUserRegistration(HttpServletRequest request,@RequestBody UserDTO userDTO)
	{
		Integer userId=userService.insertUser(userDTO);
		if(userDTO!=null)
		{
			HttpSession session=request.getSession();
			session.setAttribute("AUTH_USER", userDTO);
			return "redirect:userHome";
		}
		return "userRegistration";
	}
	@RequestMapping(name="/userRegistration",method = RequestMethod.GET)
	public String userRegistration()
	{
		return"userRegistration";
	}
	
}
