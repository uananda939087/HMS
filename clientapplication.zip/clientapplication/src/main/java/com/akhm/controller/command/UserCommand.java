package com.akhm.controller.command;

import lombok.Data;

@Data
public class UserCommand {
	private String emailId;
	private String lastName;
}
