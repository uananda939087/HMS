package com.akhm.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.akhm.dto.CustomerDTO;
import com.akhm.dto.UserDTO;
@FeignClient(url = "http://localhost:8761")
public interface CustomerClient {
	@RequestMapping(method = RequestMethod.POST, value = "/registration")
	public Integer saveUser(CustomerDTO customerDTO);

	@RequestMapping(method = RequestMethod.GET, value = "/isUserExist")
	public boolean isUserExist(String emailId);

	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public CustomerDTO getUser(CustomerDTO customerDTO);

}
