package com.akhm.repository;

import org.springframework.stereotype.Repository;

import com.akhm.repository.entity.AdminEntity;

@Repository
public interface AdminRepository {
	public AdminEntity findByEmailIdAndPassword(String emailId,String password);
}
