package com.akhm.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akhm.exception.AdminDataCustomException;
import com.akhm.repository.entity.AdminEntity;
import com.akhm.service.AdminService;





@RestController
@RequestMapping("/admin/v0")
public class AdminController {
	@Autowired
	private AdminService adminService;
	@PostMapping("/login")
	public ResponseEntity<AdminEntity> logIn(@RequestBody Map<String, String> admin)
	{
		try {
			String emailId=admin.get("emailId");
			String password=admin.get("password");
			AdminEntity adminEntity=adminService.getAdmin(emailId, password);
			if(adminEntity!=null)
			{
				return new ResponseEntity<AdminEntity>(HttpStatus.OK);
			}
			else
			{

				return new ResponseEntity<AdminEntity>(HttpStatus.UNAUTHORIZED);			}
		} catch (Exception e) {
			return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);

		}
		
	}
}
