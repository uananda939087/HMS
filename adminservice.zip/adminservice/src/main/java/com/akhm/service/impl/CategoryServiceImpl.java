package com.akhm.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.akhm.repository.entity.CategoryEntity;
import com.akhm.service.CategoryService;
@Service
public class CategoryServiceImpl implements CategoryService{
	

	@Override
	public Integer insertCategory(CategoryEntity categoryEntity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CategoryEntity> getCategories() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CategoryEntity getCategory(Integer categoryId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateCategory(CategoryEntity categoryEntity) {
		// TODO Auto-generated method stub
		
	}

}
