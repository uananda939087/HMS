package com.akhm.service;

import java.util.List;

import com.akhm.repository.entity.CategoryEntity;

public interface CategoryService {
	public Integer insertCategory(CategoryEntity categoryEntity);
	public List<CategoryEntity> getCategories();
	public CategoryEntity getCategory(Integer categoryId);
	public void updateCategory(CategoryEntity categoryEntity);
}
