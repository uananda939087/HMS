package com.akhm.exception;

public class AdminDataCustomException extends RuntimeException{
	public AdminDataCustomException(String message)
	{
		super(message);
	}
}
